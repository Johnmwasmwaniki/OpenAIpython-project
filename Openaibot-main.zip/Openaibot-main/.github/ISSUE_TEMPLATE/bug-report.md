---
name: Bug Report
about: Create a report to help us improve
title: "[BUG]"
labels: Bug
assignees: ''

---

**Describe the bug**
A clear and concise description of what the bug is.

**Log**
```
```
- [ ] **Secret in the Log has been deleted**

**Info**
Version:
