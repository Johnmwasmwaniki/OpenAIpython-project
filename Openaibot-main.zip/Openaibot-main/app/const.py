DBNAME = "openai_bot:"
