class ChainBuildException(Exception):
    pass
