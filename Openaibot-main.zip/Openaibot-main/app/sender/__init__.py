# -*- coding: utf-8 -*-
# @Time    : 2023/8/17 下午8:27
# @Author  : sudoskys
# @File    : __init__.py.py
# @Software: PyCharm

from dotenv import load_dotenv

load_dotenv()
