# -*- coding: utf-8 -*-
# @Time    : 2023/10/12 下午11:45
# @Author  : sudoskys
# @File    : __init__.py.py
# @Software: PyCharm
__plugin_meta__ = "test"
print(__plugin_meta__)
