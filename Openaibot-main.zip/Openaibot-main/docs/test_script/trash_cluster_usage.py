# -*- coding: utf-8 -*-
# @Time    : 2023/10/31 上午10:42
# @Author  : sudoskys
# @File    : memory_test.py
# @Software: PyCharm
from llmkira.sdk.filter import reduce
pre = reduce.Cluster()
print(pre)
# from llmkira.sdk.filter import langdetect_fasttext

# print(langdetect_fasttext)
