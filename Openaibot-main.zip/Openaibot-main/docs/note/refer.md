讲的不错的文章。

pydantic
https://qiita.com/koralle/items/93b094ddb6d3af917702
https://github.com/openai/openai-python/blob/main/chatml.md

interesting project
https://janekb04.github.io/py2gpt/
https://github.com/janekb04/py2gpt/blob/main/main.py

How to format inputs to ChatGPT models
https://github.com/openai/openai-cookbook/blob/main/examples/How_to_format_inputs_to_ChatGPT_models.ipynb

LLM+Embedding构建问答系统的局限性及优化方案
https://zhuanlan.zhihu.com/p/641132245

ChatGPT 越过山丘之后，再来谈谈 LLM 应用方向
https://quail.ink/orange/p/chatgpt-cross-over-the-hills-and-discuss-llm-application-directions

ChatGPT代码解释器非常强大
https://mp.weixin.qq.com/s/nob0sd6NYgbP1vwRyoQvig

Openai Api Docs
https://platform.openai.com/docs/api-reference/completions

GOT
https://github.com/spcl/graph-of-thoughts

AI Agents大爆发：软件2.0雏形初现，OpenAI的下一步
https://mp.weixin.qq.com/s/Jb8HBbaKYXXxTSQOBsP5Wg

ChatGPT Plugin：被高估的“App Store时刻”，软件和SaaS生态的重组开端
https://mp.weixin.qq.com/s?__biz=Mzg2OTY0MDk0NQ==&mid=2247502626&idx=1&sn=17603eac4304cbe6508866910e2943f3&chksm=ce9b74bcf9ecfdaa3589356f8e2a6351831955d49cf65f22a43ba90559782d20522f629c9448&scene=21#wechat_redirect

LangChain？
https://twitter.com/AravSrinivas/status/1677884199183994881
https://minimaxir.com/2023/07/langchain-problem/

"""
1 lock
2 ...
1 ...
2 lock
1 ...
2 ...
3 lock
"""
